package com.zeno.aim

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/**
 * شاشة اختبار: تعرض كل لمسة (حقيقية أو مُحقنة من AIM) مع مسارها،
 * لتتأكد من أن الجويستيك والكاميرا والأزرار تعمل قبل تجربة لعبة حقيقية.
 */
class TestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(TouchView(this))
    }
}

class TouchView(ctx: Context) : View(ctx) {
    private val trails = HashMap<Int, ArrayList<PointF>>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val colors = intArrayOf(
        0xFF00E5FF.toInt(), 0xFFFFC400.toInt(), 0xFFFF5252.toInt(), 0xFF69F0AE.toInt(),
        0xFFE040FB.toInt(), 0xFFFFAB40.toInt()
    )

    init {
        setBackgroundColor(0xFF101418.toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val list = ArrayList<PointF>()
                list.add(PointF(e.getX(i), e.getY(i)))
                trails[e.getPointerId(i)] = list
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val list = trails[e.getPointerId(i)] ?: continue
                    list.add(PointF(e.getX(i), e.getY(i)))
                    if (list.size > 80) list.removeAt(0)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                trails.remove(e.getPointerId(e.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> trails.clear()
        }
        invalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        paint.textSize = 34f
        paint.style = Paint.Style.FILL
        paint.color = 0xFFB0B0B0.toInt()
        canvas.drawText("Touch test — active pointers: " + trails.size, 24f, 48f, paint)
        canvas.drawText("Enable AIM, then use keyboard / mouse here.", 24f, 92f, paint)

        for ((id, list) in trails) {
            if (list.isEmpty()) continue
            val col = colors[id % colors.size]
            paint.color = col
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            for (i in 1 until list.size) {
                canvas.drawLine(list[i - 1].x, list[i - 1].y, list[i].x, list[i].y, paint)
            }
            val last = list[list.size - 1]
            paint.style = Paint.Style.FILL
            canvas.drawCircle(last.x, last.y, 36f, paint)
            paint.color = 0xFFFFFFFF.toInt()
            canvas.drawText(
                "#" + id + " (" + last.x.toInt() + "," + last.y.toInt() + ")",
                last.x + 48f, last.y - 12f, paint
            )
        }
    }
}

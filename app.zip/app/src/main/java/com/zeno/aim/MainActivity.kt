package com.zeno.aim

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var target: TextView
    private lateinit var swEnabled: Switch
    private lateinit var swHud: Switch

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 15f, bold: Boolean = false, color: Int = 0xFFE0E0E0.toInt()): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(6), 0, dp(6))
        return t
    }

    private fun button(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(24))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL

        root.addView(text("AIM — Advanced Input Mapper", 22f, true, Color.WHITE))
        status = text("", 15f, true)
        root.addView(status)

        root.addView(
            text(
                "إفصاح: يستخدم التطبيق خدمة «إمكانية الوصول» فقط لأمرين: (1) استقبال ضغطات الكيبورد وأزرار " +
                    "يد التحكم، و(2) تنفيذ لمسات داخل التطبيق الذي تختاره. لا يقرأ محتوى الشاشة، ولا يخزّن " +
                    "ما تكتبه، ولا يملك صلاحية الإنترنت.",
                13f, false, 0xFFB0B0B0.toInt()
            )
        )

        root.addView(button("1) فتح إعدادات إمكانية الوصول وتفعيل AIM") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        swEnabled = Switch(this)
        swEnabled.text = "2) تشغيل التحويل"
        swEnabled.setTextColor(Color.WHITE)
        root.addView(swEnabled)

        swHud = Switch(this)
        swHud.text = "إظهار HUD (دوائر الجويستيك والكاميرا والأزرار)"
        swHud.setTextColor(Color.WHITE)
        root.addView(swHud)

        target = text("", 14f)
        root.addView(target)
        root.addView(button("3) اختيار اللعبة / التطبيق المستهدف") { pickApp() })
        root.addView(button("تعديل البروفايل (مواضع الأزرار والحساسية)") {
            startActivity(Intent(this, ProfileEditorActivity::class.java))
        })
        root.addView(button("شاشة اختبار اللمس (بدون لعبة)") {
            startActivity(Intent(this, TestActivity::class.java))
        })

        root.addView(
            text(
                "اختصار الطوارئ: اضغط F10 على الكيبورد لإيقاف/استئناف التحويل مؤقتاً (مثلاً للكتابة داخل اللعبة). " +
                    "لو علق شيء، أوقف مفتاح التشغيل أو أوقف الخدمة من إعدادات إمكانية الوصول.",
                13f, false, 0xFFB0B0B0.toInt()
            )
        )

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF121212.toInt())
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()

        val a11y = a11yEnabled()
        val live = AimService.instance != null
        status.text = when {
            live -> "الحالة: الخدمة تعمل ✓"
            a11y -> "الحالة: الخدمة مفعّلة لكنها لم تبدأ بعد"
            else -> "الحالة: الخدمة غير مفعّلة ✗ (أندرويد 13+: قد تحتاج «السماح بالإعدادات المقيّدة» من معلومات التطبيق)"
        }
        status.setTextColor(if (live) 0xFF69F0AE.toInt() else 0xFFFF8A80.toInt())

        swEnabled.setOnCheckedChangeListener(null)
        swEnabled.isChecked = Store.enabled(this)
        swEnabled.setOnCheckedChangeListener { _, v ->
            Store.setEnabled(this, v)
            if (v && AimService.instance == null) {
                Toast.makeText(this, "فعّل خدمة AIM من إعدادات إمكانية الوصول أولاً", Toast.LENGTH_LONG).show()
            }
        }

        swHud.setOnCheckedChangeListener(null)
        swHud.isChecked = Store.hud(this)
        swHud.setOnCheckedChangeListener { _, v -> Store.setHud(this, v) }

        refreshTarget()
    }

    private fun refreshTarget() {
        val pkg = try {
            JSONObject(Store.json(this)).optString("targetPackage", "")
        } catch (e: Exception) {
            ""
        }
        target.text = "التطبيق المستهدف: " + if (pkg.isEmpty()) "كل التطبيقات (احذر: ستُستهلك أزرار الكيبورد المربوطة في كل مكان)" else pkg
    }

    private fun a11yEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.split(':').any { it.startsWith("$packageName/") }
    }

    @Suppress("DEPRECATION")
    private fun pickApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val labels = ArrayList<String>()
        labels.add("كل التطبيقات")
        for (a in apps) labels.add(a.second + "  (" + a.first + ")")

        AlertDialog.Builder(this)
            .setTitle("اختر التطبيق المستهدف")
            .setItems(labels.toTypedArray()) { _, i ->
                val pkg = if (i == 0) "" else apps[i - 1].first
                try {
                    val o = JSONObject(Store.json(this))
                    o.put("targetPackage", pkg)
                    Store.saveJson(this, o.toString(2))
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذّر الحفظ: " + e.message, Toast.LENGTH_LONG).show()
                }
                refreshTarget()
            }
            .show()
    }
}

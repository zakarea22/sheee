package com.zeno.aim

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import kotlin.math.abs

/**
 * يحقن لمسات متعددة ومستمرة عبر dispatchGesture.
 * كل "إصبع" افتراضي له id. نرسل مقاطع قصيرة (SEG_MS) متصلة بـ willContinue/continueStroke
 * فيبقى الإصبع مضغوطاً ويتحرك بسلاسة، ثم نُنهي المقطع الأخير عند الرفع.
 */
class GestureDispatcher(private val svc: AccessibilityService) {

    private class Ptr(var x: Float, var y: Float) {
        var tx = x
        var ty = y
        var stroke: GestureDescription.StrokeDescription? = null
        var releasing = false
        var restartX = Float.NaN
        var restartY = Float.NaN
    }

    private val ptrs = LinkedHashMap<Int, Ptr>()
    private val main = Handler(Looper.getMainLooper())
    private var inFlight = false

    private companion object {
        const val SEG_MS = 40L
    }

    fun isDown(id: Int): Boolean {
        val p = ptrs[id] ?: return false
        return !p.releasing || !p.restartX.isNaN()
    }

    fun down(id: Int, x: Float, y: Float) {
        val old = ptrs[id]
        if (old == null) {
            ptrs[id] = Ptr(x, y)
        } else if (old.releasing) {
            old.restartX = x
            old.restartY = y
        } else {
            old.tx = x
            old.ty = y
        }
        pump()
    }

    fun move(id: Int, x: Float, y: Float) {
        val p = ptrs[id] ?: return
        if (p.releasing) return
        p.tx = x
        p.ty = y
        pump()
    }

    fun up(id: Int) {
        val p = ptrs[id] ?: return
        p.releasing = true
        p.restartX = Float.NaN
        p.restartY = Float.NaN
        pump()
    }

    fun tap(id: Int, x: Float, y: Float, holdMs: Long = 50L) {
        down(id, x, y)
        main.postDelayed({ up(id) }, holdMs)
    }

    fun releaseAll() {
        for (p in ptrs.values) {
            p.releasing = true
            p.restartX = Float.NaN
            p.restartY = Float.NaN
        }
        pump()
    }

    private fun pump() {
        if (inFlight || ptrs.isEmpty()) return

        val builder = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        var n = 0
        for (p in ptrs.values) {
            if (n >= max) break
            val path = Path()
            path.moveTo(p.x, p.y)
            if (abs(p.tx - p.x) > 0.5f || abs(p.ty - p.y) > 0.5f) path.lineTo(p.tx, p.ty)
            val willContinue = !p.releasing
            val prev = p.stroke
            val s = if (prev == null) {
                GestureDescription.StrokeDescription(path, 0L, SEG_MS, willContinue)
            } else {
                prev.continueStroke(path, 0L, SEG_MS, willContinue)
            }
            p.stroke = s
            p.x = p.tx
            p.y = p.ty
            builder.addStroke(s)
            n++
        }
        if (n == 0) return

        inFlight = true
        val accepted = try {
            svc.dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    finish(false)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    finish(true)
                }
            }, main)
        } catch (e: Exception) {
            false
        }
        if (!accepted) {
            inFlight = false
            ptrs.clear()
        }
    }

    private fun finish(cancelled: Boolean) {
        inFlight = false
        val restarts = ArrayList<Triple<Int, Float, Float>>()
        val it = ptrs.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val p = e.value
            if (cancelled) p.stroke = null
            if (p.releasing) {
                if (!p.restartX.isNaN()) restarts.add(Triple(e.key, p.restartX, p.restartY))
                it.remove()
            }
        }
        for (r in restarts) ptrs[r.first] = Ptr(r.second, r.third)
        pump()
    }
}

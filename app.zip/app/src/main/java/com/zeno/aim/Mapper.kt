package com.zeno.aim

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** يحوّل أحداث الإدخال إلى أوامر لمس عبر GestureDispatcher. */
class Mapper(
    private val disp: GestureDispatcher,
    private val screen: () -> Pair<Int, Int>
) {
    var profile: Profile = Profile.parse(DEFAULT_PROFILE_JSON)
        set(value) {
            releaseAll()
            field = value
        }

    private val main = Handler(Looper.getMainLooper())

    private val moveId = 0
    private val camId = 1
    private val keyBase = 10
    private val mouseBase = 60

    private val moveKeys = HashSet<Int>()
    private var stickX = 0f
    private var stickY = 0f
    private var rsX = 0f
    private var rsY = 0f
    private var curX = 0f
    private var curY = 0f
    private var joyDown = false

    private var camDown = false
    private var camX = 0f
    private var camY = 0f
    private var camTX = 0f
    private var camTY = 0f
    private var lastCamInput = 0L
    private var prevButtons = 0

    private var looping = false
    private var lastStep = 0L
    private val loop = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastStep).coerceIn(1L, 50L).toFloat()
            lastStep = now
            if (step(dt)) {
                main.postDelayed(this, 16L)
            } else {
                looping = false
            }
        }
    }

    private fun ensureLoop() {
        if (!looping) {
            looping = true
            lastStep = SystemClock.uptimeMillis() - 16L
            main.post(loop)
        }
    }

    // ---------------------------------------------------------------- المدخلات

    /** يرجع true إذا كان المفتاح مربوطاً (فيُستهلك ولا يصل للعبة). */
    fun onKey(code: Int, down: Boolean, repeat: Int): Boolean {
        var consumed = false
        val m = profile.move
        if (code == m.up || code == m.down || code == m.left || code == m.right) {
            if (down) moveKeys.add(code) else moveKeys.remove(code)
            ensureLoop()
            consumed = true
        }
        val size = screen()
        val w = size.first.toFloat()
        val h = size.second.toFloat()
        profile.keys.forEachIndexed { i, k ->
            if (k.code != code) return@forEachIndexed
            consumed = true
            if (repeat > 0) return@forEachIndexed
            val id = keyBase + i
            val x = k.x * w
            val y = k.y * h
            if (k.action == "hold") {
                if (down) disp.down(id, x, y) else disp.up(id)
            } else if (down) {
                disp.tap(id, x, y)
            }
        }
        return consumed
    }

    fun onAxes(x: Float, y: Float, z: Float, rz: Float) {
        stickX = x
        stickY = y
        rsX = z
        rsY = rz
        ensureLoop()
    }

    fun onMouseDelta(dx: Float, dy: Float) {
        val c = profile.camera
        val len = hypot(dx, dy)
        if (len == 0f) return
        val gain = if (c.curve == "exp") 1f + min(len, 40f) / 20f else 1f
        val sx = if (c.invertX) -1f else 1f
        val sy = if (c.invertY) -1f else 1f
        moveCam(dx * c.sensitivity * gain * sx, dy * c.sensitivity * gain * sy)
    }

    fun onMouseButtons(state: Int) {
        if (state == prevButtons) return
        val size = screen()
        val w = size.first.toFloat()
        val h = size.second.toFloat()
        profile.mouse.forEachIndexed { i, b ->
            val mask = when (b.button) {
                "left" -> MotionEvent.BUTTON_PRIMARY
                "right" -> MotionEvent.BUTTON_SECONDARY
                "middle" -> MotionEvent.BUTTON_TERTIARY
                else -> 0
            }
            if (mask == 0) return@forEachIndexed
            val now = (state and mask) != 0
            val was = (prevButtons and mask) != 0
            if (now == was) return@forEachIndexed
            val id = mouseBase + i
            val x = b.x * w
            val y = b.y * h
            if (b.action == "hold") {
                if (now) disp.down(id, x, y) else disp.up(id)
            } else if (now) {
                disp.tap(id, x, y)
            }
        }
        prevButtons = state
    }

    fun releaseAll() {
        moveKeys.clear()
        stickX = 0f; stickY = 0f; rsX = 0f; rsY = 0f
        curX = 0f; curY = 0f
        joyDown = false
        camDown = false
        prevButtons = 0
        disp.releaseAll()
    }

    // ---------------------------------------------------------------- الكاميرا

    private fun moveCam(dx: Float, dy: Float) {
        val size = screen()
        val w = size.first.toFloat()
        val h = size.second.toFloat()
        val c = profile.camera
        val cx = c.cx * w
        val cy = c.cy * h
        val r = c.radius * min(w, h)
        if (!camDown) {
            camX = cx; camY = cy; camTX = cx; camTY = cy
            disp.down(camId, cx, cy)
            camDown = true
        }
        camTX += dx
        camTY += dy
        if (hypot(camTX - cx, camTY - cy) > r) {
            // وصلنا حافة المنطقة: ارفع الإصبع وابدأ من المركز
            disp.up(camId)
            camX = cx; camY = cy; camTX = cx; camTY = cy
            disp.down(camId, cx, cy)
        }
        lastCamInput = SystemClock.uptimeMillis()
        ensureLoop()
    }

    // ---------------------------------------------------------------- الحلقة (16ms)

    private fun step(dt: Float): Boolean {
        val size = screen()
        val w = size.first.toFloat()
        val h = size.second.toFloat()
        val side = min(w, h)
        val m = profile.move
        val c = profile.camera

        // الحركة
        var tx = 0f
        var ty = 0f
        if (m.left in moveKeys) tx -= 1f
        if (m.right in moveKeys) tx += 1f
        if (m.up in moveKeys) ty -= 1f
        if (m.down in moveKeys) ty += 1f
        if (tx != 0f || ty != 0f) {
            val l = hypot(tx, ty)
            tx /= l
            ty /= l
        } else if (m.gamepadStick) {
            val mag = hypot(stickX, stickY)
            if (mag > m.deadZone) {
                val s = ((mag - m.deadZone) / (1f - m.deadZone)).coerceAtMost(1f)
                tx = stickX / mag * s
                ty = stickY / mag * s
            }
        }
        tx *= m.maxSpeed
        ty *= m.maxSpeed
        curX = approach(curX, tx, dt, m)
        curY = approach(curY, ty, dt, m)

        val moving = abs(curX) > 0.01f || abs(curY) > 0.01f || tx != 0f || ty != 0f
        if (moving) {
            val cx = m.cx * w
            val cy = m.cy * h
            val r = m.radius * side
            if (!joyDown) {
                disp.down(moveId, cx, cy)
                joyDown = true
            }
            disp.move(moveId, cx + curX * r, cy + curY * r)
        } else if (joyDown) {
            disp.up(moveId)
            joyDown = false
            curX = 0f
            curY = 0f
        }

        // الكاميرا بالعصا اليمنى
        var rsActive = false
        if (c.gamepadStick) {
            val mag = hypot(rsX, rsY)
            if (mag > 0.15f) {
                rsActive = true
                val s = ((mag - 0.15f) / 0.85f).coerceAtMost(1f)
                val k = s * c.stickSpeed * dt / 1000f
                val sx = if (c.invertX) -1f else 1f
                val sy = if (c.invertY) -1f else 1f
                moveCam(rsX / mag * k * sx, rsY / mag * k * sy)
            }
        }

        // تنعيم الكاميرا + الرفع عند الخمول
        if (camDown) {
            val a = if (c.smoothing <= 0.01f) 1f else (1f - c.smoothing).coerceIn(0.05f, 1f)
            camX += (camTX - camX) * a
            camY += (camTY - camY) * a
            disp.move(camId, camX, camY)
            val idle = SystemClock.uptimeMillis() - lastCamInput > c.idleMs
            if (idle && abs(camTX - camX) < 1f && abs(camTY - camY) < 1f) {
                disp.up(camId)
                camDown = false
            }
        }

        return joyDown || camDown || rsActive
    }

    private fun approach(cur: Float, target: Float, dt: Float, m: MoveCfg): Float {
        val ms = if (abs(target) > abs(cur)) m.accelMs else m.decelMs
        val step = if (ms <= 1f) 10f else dt / ms
        return if (target > cur) min(cur + step, target) else max(cur - step, target)
    }
}

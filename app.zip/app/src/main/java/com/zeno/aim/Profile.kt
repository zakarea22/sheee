package com.zeno.aim

import android.view.KeyEvent
import org.json.JSONObject

data class KeyBind(val code: Int, val x: Float, val y: Float, val action: String)

data class MouseBind(val button: String, val x: Float, val y: Float, val action: String)

data class MoveCfg(
    val cx: Float, val cy: Float, val radius: Float,
    val accelMs: Float, val decelMs: Float, val deadZone: Float, val maxSpeed: Float,
    val up: Int, val down: Int, val left: Int, val right: Int,
    val gamepadStick: Boolean
)

data class CameraCfg(
    val cx: Float, val cy: Float, val radius: Float,
    val sensitivity: Float, val smoothing: Float,
    val invertX: Boolean, val invertY: Boolean,
    val curve: String, val idleMs: Long,
    val stickSpeed: Float, val gamepadStick: Boolean
)

data class Profile(
    val name: String,
    val targetPackage: String,
    val toggleKey: Int,
    val capture: Boolean,
    val move: MoveCfg,
    val camera: CameraCfg,
    val keys: List<KeyBind>,
    val mouse: List<MouseBind>
) {
    companion object {
        fun keyCode(raw: String): Int {
            val s = raw.trim()
            val n = s.toIntOrNull()
            if (n != null) return n
            val c = KeyEvent.keyCodeFromString(s)
            if (c == KeyEvent.KEYCODE_UNKNOWN) throw IllegalArgumentException("مفتاح غير معروف: $s")
            return c
        }

        /** يرمي استثناء برسالة مفهومة إذا كان الـ JSON غير صالح. */
        fun parse(text: String): Profile {
            val o = JSONObject(text)
            val mv = o.optJSONObject("move") ?: JSONObject()
            val cm = o.optJSONObject("camera") ?: JSONObject()

            val move = MoveCfg(
                cx = mv.optDouble("cx", 0.16).toFloat(),
                cy = mv.optDouble("cy", 0.68).toFloat(),
                radius = mv.optDouble("radius", 0.10).toFloat(),
                accelMs = mv.optDouble("accelMs", 80.0).toFloat(),
                decelMs = mv.optDouble("decelMs", 60.0).toFloat(),
                deadZone = mv.optDouble("deadZone", 0.12).toFloat().coerceIn(0f, 0.9f),
                maxSpeed = mv.optDouble("maxSpeed", 1.0).toFloat().coerceIn(0.1f, 1f),
                up = keyCode(mv.optString("up", "KEYCODE_W")),
                down = keyCode(mv.optString("down", "KEYCODE_S")),
                left = keyCode(mv.optString("left", "KEYCODE_A")),
                right = keyCode(mv.optString("right", "KEYCODE_D")),
                gamepadStick = mv.optBoolean("gamepadStick", true)
            )
            val camera = CameraCfg(
                cx = cm.optDouble("cx", 0.72).toFloat(),
                cy = cm.optDouble("cy", 0.5).toFloat(),
                radius = cm.optDouble("radius", 0.30).toFloat(),
                sensitivity = cm.optDouble("sensitivity", 1.0).toFloat(),
                smoothing = cm.optDouble("smoothing", 0.3).toFloat().coerceIn(0f, 0.95f),
                invertX = cm.optBoolean("invertX", false),
                invertY = cm.optBoolean("invertY", false),
                curve = cm.optString("curve", "linear"),
                idleMs = cm.optLong("idleMs", 120L),
                stickSpeed = cm.optDouble("stickSpeed", 900.0).toFloat(),
                gamepadStick = cm.optBoolean("gamepadStick", true)
            )

            val keys = ArrayList<KeyBind>()
            val ka = o.optJSONArray("keys")
            if (ka != null) for (i in 0 until ka.length()) {
                val k = ka.getJSONObject(i)
                keys.add(
                    KeyBind(
                        keyCode(k.getString("key")),
                        k.getDouble("x").toFloat(), k.getDouble("y").toFloat(),
                        k.optString("action", "tap")
                    )
                )
            }
            val mouse = ArrayList<MouseBind>()
            val ma = o.optJSONArray("mouse")
            if (ma != null) for (i in 0 until ma.length()) {
                val k = ma.getJSONObject(i)
                mouse.add(
                    MouseBind(
                        k.getString("button").lowercase(),
                        k.getDouble("x").toFloat(), k.getDouble("y").toFloat(),
                        k.optString("action", "tap")
                    )
                )
            }

            return Profile(
                name = o.optString("name", "Profile"),
                targetPackage = o.optString("targetPackage", ""),
                toggleKey = keyCode(o.optString("toggleKey", "KEYCODE_F10")),
                capture = o.optBoolean("capture", true),
                move = move, camera = camera, keys = keys, mouse = mouse
            )
        }
    }
}

/**
 * الإحداثيات كلها نِسَب من 0 إلى 1 (x من العرض، y من الارتفاع).
 * الأنصاف (radius) نسبة من أصغر بُعد في الشاشة.
 * action: "tap" ضغطة سريعة، "hold" يبقى الإصبع مضغوطاً ما دام الزر مضغوطاً.
 * mouse.button: left / right / middle
 */
const val DEFAULT_PROFILE_JSON = """{
  "name": "Default",
  "targetPackage": "",
  "toggleKey": "KEYCODE_F10",
  "capture": true,
  "move": {
    "cx": 0.16, "cy": 0.68, "radius": 0.10,
    "accelMs": 80, "decelMs": 60, "deadZone": 0.12, "maxSpeed": 1.0,
    "up": "KEYCODE_W", "down": "KEYCODE_S", "left": "KEYCODE_A", "right": "KEYCODE_D",
    "gamepadStick": true
  },
  "camera": {
    "cx": 0.72, "cy": 0.50, "radius": 0.30,
    "sensitivity": 1.0, "smoothing": 0.3,
    "invertX": false, "invertY": false,
    "curve": "linear", "idleMs": 120,
    "stickSpeed": 900, "gamepadStick": true
  },
  "keys": [
    { "key": "KEYCODE_SPACE",      "x": 0.90, "y": 0.72, "action": "tap" },
    { "key": "KEYCODE_SHIFT_LEFT", "x": 0.82, "y": 0.84, "action": "hold" },
    { "key": "KEYCODE_E",          "x": 0.80, "y": 0.60, "action": "tap" },
    { "key": "KEYCODE_BUTTON_A",   "x": 0.90, "y": 0.72, "action": "tap" },
    { "key": "KEYCODE_BUTTON_X",   "x": 0.80, "y": 0.60, "action": "tap" }
  ],
  "mouse": [
    { "button": "left",  "x": 0.88, "y": 0.50, "action": "hold" },
    { "button": "right", "x": 0.75, "y": 0.35, "action": "tap" }
  ]
}"""

package com.zeno.aim

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.min

fun realSize(ctx: Context): Pair<Int, Int> {
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    return if (Build.VERSION.SDK_INT >= 30) {
        val b = wm.maximumWindowMetrics.bounds
        Pair(b.width(), b.height())
    } else {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        Pair(m.widthPixels, m.heightPixels)
    }
}

/**
 * نافذة شفافة بحجم الشاشة تأخذ الـ focus وتفعّل Pointer Capture،
 * لأن AccessibilityService لا يستقبل حركة الماوس ولا محاور العصي مباشرة.
 */
class CaptureView(ctx: Context, private val mapper: Mapper) : View(ctx) {

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            requestFocus()
            requestPointerCapture()
        }
    }

    override fun onCapturedPointerEvent(event: MotionEvent): Boolean {
        var dx = event.x
        var dy = event.y
        for (i in 0 until event.historySize) {
            dx += event.getHistoricalX(i)
            dy += event.getHistoricalY(i)
        }
        if (event.actionMasked == MotionEvent.ACTION_MOVE || event.actionMasked == MotionEvent.ACTION_HOVER_MOVE) {
            mapper.onMouseDelta(dx, dy)
        }
        mapper.onMouseButtons(event.buttonState)
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            event.actionMasked == MotionEvent.ACTION_MOVE
        ) {
            mapper.onAxes(
                event.getAxisValue(MotionEvent.AXIS_X),
                event.getAxisValue(MotionEvent.AXIS_Y),
                event.getAxisValue(MotionEvent.AXIS_Z),
                event.getAxisValue(MotionEvent.AXIS_RZ)
            )
            return true
        }
        if ((event.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE) {
            mapper.onMouseButtons(event.buttonState)
            return true
        }
        return false
    }

    // مفاتيح غير مربوطة تصل هنا لأن النافذة هي المركّزة؛ نتجاهلها.
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean = false
}

/** رسم دوائر الجويستيك والكاميرا ونقاط الأزرار لتعرف أين ستقع اللمسات. */
class HudView(ctx: Context) : View(ctx) {
    var profile: Profile? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val pr = profile ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val side = min(w, h)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = 0xAA00E5FF.toInt()
        canvas.drawCircle(pr.move.cx * w, pr.move.cy * h, pr.move.radius * side, paint)
        paint.color = 0xAAFFC400.toInt()
        canvas.drawCircle(pr.camera.cx * w, pr.camera.cy * h, pr.camera.radius * side, paint)

        paint.textSize = side * 0.03f
        paint.textAlign = Paint.Align.CENTER
        for (k in pr.keys) {
            paint.style = Paint.Style.STROKE
            paint.color = 0xAAFFFFFF.toInt()
            canvas.drawCircle(k.x * w, k.y * h, side * 0.035f, paint)
            paint.style = Paint.Style.FILL
            canvas.drawText(label(k.code), k.x * w, k.y * h + paint.textSize / 3f, paint)
        }
        for (b in pr.mouse) {
            paint.style = Paint.Style.STROKE
            paint.color = 0xAAFF5252.toInt()
            canvas.drawCircle(b.x * w, b.y * h, side * 0.035f, paint)
            paint.style = Paint.Style.FILL
            canvas.drawText("M-" + b.button.take(1).uppercase(), b.x * w, b.y * h + paint.textSize / 3f, paint)
        }
    }

    private fun label(code: Int): String =
        KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_").removePrefix("BUTTON_").take(5)
}

class Overlays(private val svc: AccessibilityService, private val mapper: Mapper) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var capture: CaptureView? = null
    private var hud: HudView? = null

    private fun params(focusable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.title = "AIM"
        return lp
    }

    fun update(wantCapture: Boolean, wantHud: Boolean, profile: Profile) {
        if (wantCapture && capture == null) {
            val v = CaptureView(svc, mapper)
            try {
                wm.addView(v, params(true))
                capture = v
                v.post {
                    v.requestFocus()
                    v.requestPointerCapture()
                }
            } catch (e: Exception) {
                // لم تُضف النافذة؛ نكمل بدون التقاط الماوس
            }
        } else if (!wantCapture && capture != null) {
            removeCapture()
        }

        if (wantHud && hud == null) {
            val v = HudView(svc)
            try {
                wm.addView(v, params(false))
                hud = v
            } catch (e: Exception) {
            }
        } else if (!wantHud && hud != null) {
            removeHud()
        }
        hud?.let {
            it.profile = profile
            it.invalidate()
        }
    }

    private fun removeCapture() {
        val v = capture ?: return
        try {
            v.releasePointerCapture()
        } catch (e: Exception) {
        }
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
        capture = null
    }

    private fun removeHud() {
        val v = hud ?: return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
        hud = null
    }

    fun removeAll() {
        removeCapture()
        removeHud()
    }
}

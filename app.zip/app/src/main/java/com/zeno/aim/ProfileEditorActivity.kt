package com.zeno.aim

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** محرر JSON بسيط للبروفايل مع التحقق قبل الحفظ. */
class ProfileEditorActivity : Activity() {

    private lateinit var edit: EditText

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF121212.toInt())
        root.setPadding(dp(12), dp(16), dp(12), dp(12))

        val hint = TextView(this)
        hint.text = "كل الإحداثيات نِسَب من 0 إلى 1 (x من العرض، y من الارتفاع). " +
            "الأنصاف نسبة من أصغر بُعد. action: tap أو hold. mouse.button: left/right/middle."
        hint.setTextColor(0xFFB0B0B0.toInt())
        hint.textSize = 12f
        root.addView(hint)

        edit = EditText(this)
        edit.setTypeface(Typeface.MONOSPACE)
        edit.textSize = 12f
        edit.setTextColor(Color.WHITE)
        edit.gravity = Gravity.TOP or Gravity.START
        edit.setHorizontallyScrolling(true)
        edit.setText(prettyOrRaw(Store.json(this)))
        root.addView(edit, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val save = Button(this)
        save.text = "حفظ"
        save.setOnClickListener { save() }
        row.addView(save, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val reset = Button(this)
        reset.text = "الافتراضي"
        reset.setOnClickListener {
            val keepTarget = try {
                JSONObject(edit.text.toString()).optString("targetPackage", "")
            } catch (e: Exception) {
                ""
            }
            val o = JSONObject(DEFAULT_PROFILE_JSON)
            o.put("targetPackage", keepTarget)
            edit.setText(o.toString(2))
        }
        row.addView(reset, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        root.addView(row)
        setContentView(root)
    }

    private fun prettyOrRaw(s: String): String = try {
        JSONObject(s).toString(2)
    } catch (e: Exception) {
        s
    }

    private fun save() {
        val s = edit.text.toString()
        try {
            Profile.parse(s)
        } catch (e: Exception) {
            Toast.makeText(this, "خطأ في الملف: " + e.message, Toast.LENGTH_LONG).show()
            return
        }
        Store.saveJson(this, s)
        Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
        finish()
    }
}

package com.zeno.aim

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class AimService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AimService? = null
    }

    private lateinit var mapper: Mapper
    private lateinit var overlays: Overlays
    private val main = Handler(Looper.getMainLooper())

    private var appMatches = false
    private var paused = false
    private var ready = false

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        main.post { reload() }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        mapper = Mapper(GestureDispatcher(this)) { realSize(this) }
        overlays = Overlays(this, mapper)
        ready = true
        Store.register(this, prefsListener)
        reload()
    }

    private fun reload() {
        if (!ready) return
        val p = try {
            Profile.parse(Store.json(this))
        } catch (e: Exception) {
            Toast.makeText(this, "AIM: ملف البروفايل غير صالح، استُخدم الافتراضي", Toast.LENGTH_LONG).show()
            Profile.parse(DEFAULT_PROFILE_JSON)
        }
        mapper.profile = p
        refresh()
    }

    private fun refresh() {
        if (!ready) return
        val run = Store.enabled(this) && appMatches && !paused
        if (run) {
            overlays.update(mapper.profile.capture, Store.hud(this), mapper.profile)
        } else {
            overlays.removeAll()
            mapper.releaseAll()
        }
    }

    private fun isRunning() = ready && Store.enabled(this) && appMatches && !paused

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!ready || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""

        val newMatch: Boolean = when {
            pkg == packageName -> {
                // نافذتنا نفسها: نفعّل فقط داخل شاشة الاختبار، ونتجاهل نوافذ الـ overlay التابعة لنا
                if (cls.endsWith(".TestActivity")) true
                else if (cls.endsWith(".MainActivity") || cls.endsWith(".ProfileEditorActivity")) false
                else appMatches
            }
            pkg == "com.android.systemui" || pkg.contains("inputmethod") -> appMatches
            else -> {
                val t = mapper.profile.targetPackage
                t.isEmpty() || t == pkg
            }
        }
        if (newMatch != appMatches) {
            appMatches = newMatch
            refresh()
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!ready || !Store.enabled(this) || !appMatches) return false
        val down = event.action == KeyEvent.ACTION_DOWN

        if (event.keyCode == mapper.profile.toggleKey) {
            if (down && event.repeatCount == 0) {
                paused = !paused
                Toast.makeText(
                    this,
                    if (paused) "AIM: متوقف مؤقتاً" else "AIM: يعمل",
                    Toast.LENGTH_SHORT
                ).show()
                refresh()
            }
            return true
        }
        if (!isRunning()) return false
        return mapper.onKey(event.keyCode, down, event.repeatCount)
    }

    override fun onInterrupt() {
        if (ready) mapper.releaseAll()
    }

    override fun onDestroy() {
        if (ready) {
            Store.unregister(this, prefsListener)
            overlays.removeAll()
            mapper.releaseAll()
        }
        ready = false
        instance = null
        super.onDestroy()
    }
}

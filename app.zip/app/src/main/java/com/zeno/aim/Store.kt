package com.zeno.aim

import android.content.Context
import android.content.SharedPreferences

object Store {
    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("aim", Context.MODE_PRIVATE)

    fun json(c: Context): String = sp(c).getString("profile", null) ?: DEFAULT_PROFILE_JSON
    fun saveJson(c: Context, s: String) = sp(c).edit().putString("profile", s).apply()

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun hud(c: Context): Boolean = sp(c).getBoolean("hud", true)
    fun setHud(c: Context, v: Boolean) = sp(c).edit().putBoolean("hud", v).apply()

    fun register(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sp(c).registerOnSharedPreferenceChangeListener(l)

    fun unregister(c: Context, l: SharedPreferences.OnSharedPreferenceChangeListener) =
        sp(c).unregisterOnSharedPreferenceChangeListener(l)
}
